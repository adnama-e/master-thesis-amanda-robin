def lambda_handler(event, context):
	dates = event["datetime"]
	drive_id = event["driveId"]
	scores = event["score"]
	user_id = event["userId"]
	drive_score(scores)
	return "really?"


def drive_score(scores):
	"""
	Converts the driving scores into a 1 to 5 star rating for the current drive.
	:param scores: The scores from the latest drive.
	:return: The rating.
	"""
	summed_score = sum([float(score) for score in scores])
	print(summed_score)
	

def improvement_score():
	pass



